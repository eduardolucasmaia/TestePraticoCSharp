﻿using Business.Entities.DataModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Data.Interfaces
{
    public interface IUsuarioData
    {
        #region CONSULTAS
        Task<Usuario> AutenticarUsuario(string username, string senha);
        Task<List<Usuario>> BuscarUsuarios(int id);
        Task<Usuario> BuscarUsuarioPorId(int id);
        Task<Usuario> BuscarUsuarioPorEmail(string email);
        Task<string> BuscarFotoPerfilUsuarioAtual(int id);
        #endregion
        #region AÇÕES
        Task<bool> SalvarUsuario(Usuario model);
        Task<bool> ExcluirUsuario(int id);
        Task<Usuario> TrocarSenha(string senhaAntiga, string novaSenha, int id);
        #endregion
    }
}