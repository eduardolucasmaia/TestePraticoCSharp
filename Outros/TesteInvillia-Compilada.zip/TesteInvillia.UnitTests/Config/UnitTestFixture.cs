﻿using AutoMapper;
using Business;
using Business.Entities.DataModels;
using Business.Interfaces;
using Data;
using Data.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.Extensions.DependencyInjection;

namespace TesteInvillia.UnitTests.Config
{
    public class UnitTestFixture
    {
        public UnitTestFixture()
        {
            ConfigurationString.Connection.Add("DefaultConnection", ConnectionStringTests.CONNECTION_STRING_TEST);

            var serviceCollection = new ServiceCollection();
            serviceCollection.AddHttpContextAccessor();
            serviceCollection.AddScoped<IUsuarioBusiness, UsuarioBusiness>();
            serviceCollection.AddScoped<IUsuarioData, UsuarioData>();
            serviceCollection.AddScoped<IJogoBusiness, JogoBusiness>();
            serviceCollection.AddScoped<IJogoData, JogoData>();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Usuario, UsuarioDTO>()
                .ForMember(x => x.Senha, opt => opt.Ignore())
                .ForMember(x => x.InverseIdCriadoUsuarioNavigation, opt => opt.Ignore());

                cfg.CreateMap<Role, RoleDTO>()
                .ForMember(x => x.VinculoUsuarioRole, opt => opt.Ignore());

                cfg.CreateMap<VinculoUsuarioRole, VinculoUsuarioRoleDTO>()
                .ForMember(x => x.IdUsuarioNavigation, opt => opt.Ignore());

                cfg.CreateMap<Jogo, JogoDTO>();
            });

            IMapper mapper = config.CreateMapper();
            serviceCollection.AddSingleton(mapper);

            ServiceProvider = serviceCollection.BuildServiceProvider();

        }
        public ServiceProvider ServiceProvider { get; private set; }
    }
}
