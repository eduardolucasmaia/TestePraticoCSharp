﻿using AutoMapper;
using Business;
using Business.Entities.DataModels;
using Data;
using DTO.DTO;
using DTO.Ferramentas;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TesteInvillia.UnitTests.Config;
using Xunit;

namespace TesteInvillia.UnitTests
{
    public class TheoriesTest
    {
        #region Construtor

        private readonly JogoBusiness _jogoBusiness;
        private readonly UsuarioBusiness _usuarioBusiness;

        public TheoriesTest()
        {
            if (!ConfigurationString.Connection.ContainsKey("DefaultConnection"))    
                ConfigurationString.Connection.Add("DefaultConnection", ConnectionStringTests.CONNECTION_STRING_TEST);

            JogoData _jogoData = new JogoData();
            UsuarioData _usuarioData = new UsuarioData();

            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Usuario, UsuarioDTO>()
                .ForMember(x => x.Senha, opt => opt.Ignore())
                .ForMember(x => x.InverseIdCriadoUsuarioNavigation, opt => opt.Ignore());

                cfg.CreateMap<Role, RoleDTO>()
                .ForMember(x => x.VinculoUsuarioRole, opt => opt.Ignore());

                cfg.CreateMap<VinculoUsuarioRole, VinculoUsuarioRoleDTO>()
                .ForMember(x => x.IdUsuarioNavigation, opt => opt.Ignore());

                cfg.CreateMap<Jogo, JogoDTO>();
            });

            IMapper mapper = config.CreateMapper();

            _jogoBusiness = new JogoBusiness(_jogoData, mapper);
            _usuarioBusiness = new UsuarioBusiness(_usuarioData, _jogoData, mapper);
        }

        #endregion

        #region JOGO

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarJogoPeloId(int id)
        {
            // Act
            var resultado = await _jogoBusiness.BuscarJogoPorId(id);
            // Assert
            if (resultado == null)
            {
                Assert.Null(resultado);
            }
            else
            {
                Assert.IsType<JogoDTO>(resultado);
            }
        }

        [Theory]
        [InlineData("Super")]
        [InlineData("Legend")]
        [InlineData("Castlevania")]
        public async Task BuscarJogosPeloNome(string nome)
        {
            // Act
            var resultado = await _jogoBusiness.BuscarJogoPorNome(nome);
            // Assert
            Assert.IsType<List<JogoDTO>>(resultado);
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarJogosDisponiveisIncluindoIdUsuarioLogado(int idUsuario)
        {
            // Act
            var resultado = await _jogoBusiness.BuscarJogosDisponiveis(idUsuario);
            // Assert
            Assert.IsType<List<JogoDTO>>(resultado);
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task ExcluirJogoPorId(int id)
        {
            // Act
            var resultado = await _jogoBusiness.ExcluirJogo(id);
            // Assert
            Assert.True(resultado);
        }

        [Theory]
        [InlineData(0, "2017-3-1 12:19:20", "Super Mario World", 1)]
        [InlineData(1, "2007-11-1 09:15:10", "Legend of Zelda - Majora's Mask", 2)]
        [InlineData(2, "2013-12-1 18:45:56", "Castlevania: Symphony of the Night", 3)]
        public async Task SalvarJogoPorId(int id, string data, string nome, int plataforma)
        {
            //Arrange
            var dataFormatado = DateTime.Parse(data);
            var jogo = new JogoDTO()
            {
                Id = id,
                DataCadastro = dataFormatado,
                Nome = nome,
                Plataforma = plataforma
            };
            // Act
            var resultado = await _jogoBusiness.SalvarJogo(jogo);
            // Assert
            Assert.True(resultado);
        }

        #endregion

        #region USUÁRIO

        [Theory]
        [InlineData(0, "2017-3-1 12:19:20", "Nome de Teste")]
        [InlineData(1, "2007-11-1 09:15:10", "Nome de Teste 2")]
        [InlineData(2, "2013-12-1 18:45:56", "Nome de Teste 3")]
        public async Task AtualizarPerfilUsuario(int id, string data, string nome)
        {
            //Arrange
            var dataFormatado = DateTime.Parse(data);
            var usuario = new UsuarioDTO()
            {
                Id = id,
                DataCadastro = dataFormatado,
                Nome = nome,
                Email = Constantes.EMAIL_TESTE,
                Senha = Constantes.SENHA_INICIAL
            };
            // Act
            var resultado = await _usuarioBusiness.AtualizarPerfil(usuario, id);
            // Assert
            Assert.True(resultado);
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarFotoPerfilUsuarioLogado(int id)
        {
            // Act
            var resultado = await _usuarioBusiness.BuscarFotoPerfilUsuarioAtual(id);
            // Assert
            if (resultado == null)
            {
                Assert.Null(resultado);
            }
            else
            {
                Assert.IsType<string>(resultado);
            }
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarUsuarioLogado(int id)
        {
            // Act
            var resultado = await _usuarioBusiness.BuscarUsuarioAtual(id);
            // Assert
            if (resultado == null)
            {
                Assert.Null(resultado);
            }
            else
            {
                Assert.IsType<UsuarioDTO>(resultado);
            }
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarUsuarioPeloId(int id)
        {
            // Act
            var resultado = await _usuarioBusiness.BuscarUsuarioPorId(id);
            // Assert
            if (resultado == null)
            {
                Assert.Null(resultado);
            }
            else
            {
                Assert.IsType<UsuarioDTO>(resultado);
            }
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task BuscarUsuarios(int id)
        {
            // Act
            var resultado = await _usuarioBusiness.BuscarUsuarios(id);
            // Assert
            Assert.IsType<List<UsuarioDTO>>(resultado);
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task ExcluirUsuarioPorId(int id)
        {
            // Act
            var resultado = await _usuarioBusiness.ExcluirUsuario(id);
            // Assert
            Assert.True(resultado);
        }

        [Theory]
        [InlineData(0, "2017-3-1 12:19:20", "Nome de Teste")]
        [InlineData(1, "2007-11-1 09:15:10", "Nome de Teste 2")]
        [InlineData(2, "2013-12-1 18:45:56", "Nome de Teste 3")]
        public async Task SalvarUsuario(int id, string data, string nome)
        {
            //Arrange
            var dataFormatado = DateTime.Parse(data);
            var usuario = new UsuarioDTO()
            {
                Id = id,
                DataCadastro = dataFormatado,
                Nome = nome,
                Email = Constantes.EMAIL_TESTE,
                Senha = Constantes.SENHA_INICIAL
            };
            // Act
            var resultado = await _usuarioBusiness.SalvarUsuario(usuario);
            // Assert
            Assert.True(resultado);
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(3)]
        public async Task TrocarSenhaPorId(int id)
        {
            //Arrange
            var senhaAntiga = Constantes.SENHA_INICIAL;
            var senhaNova = Constantes.SENHA_INICIAL;
            // Act
            var resultado = await _usuarioBusiness.TrocarSenha(senhaAntiga, senhaNova, id);
            // Assert
            if (resultado == null)
            {
                Assert.Null(resultado);
            }
            else
            {
                Assert.IsType<UsuarioDTO>(resultado);
            }
        }

        #endregion

    }
}
