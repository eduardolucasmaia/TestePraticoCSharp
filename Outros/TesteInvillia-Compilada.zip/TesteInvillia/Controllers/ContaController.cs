﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Business.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TesteInvillia.Models;

namespace TesteInvillia.Controllers
{
    public class ContaController : Controller
    {
        #region Contrutor

        private readonly IUsuarioBusiness _usuarioBusiness;

        public ContaController(IUsuarioBusiness usuarioBusiness)
        {
            _usuarioBusiness = usuarioBusiness;
        }

        #endregion

        #region GET

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewData["Title"] = "Login";
            if (User.Identity.IsAuthenticated)
            {
                if (Url.IsLocalUrl(returnUrl) && returnUrl.Length > 1 && returnUrl.StartsWith("/")
                       && !returnUrl.StartsWith("//") && !returnUrl.StartsWith("/\\"))
                {
                    return Redirect(returnUrl);
                }
                return RedirectToAction("Index", "Home");
            }
            try
            {
                ViewData["CompileDate"] = "Data último build: " + System.IO.File.GetLastWriteTime(Assembly.GetExecutingAssembly().Location).ToString("dd/MM/yyyy HH:mm:ss");
            }
            catch
            {
                ViewData["CompileDate"] = string.Empty;
            }
            var model = new LoginViewModel();
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult TrocarSenha(string codigo)
        {
            ViewData["Title"] = "Trocar senha";
            var model = new TrocarSenhaViewModel()
            {
                //Codigo = codigo,
                SenhaAntiga = "**********"
            };
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult EsqueceuSenha()
        {
            ViewData["Title"] = "Esqueceu a senha";
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }
            var model = new EsqueceuSenhaViewModel();
            return View(model);
        }

        #endregion

        #region POST

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewData["Title"] = "Login";
            if (ModelState.IsValid)
            {
                try
                {
                    var usuario = await _usuarioBusiness.AutenticarUsuario(model.UserName.Trim(), model.Senha.Trim());
                    if (usuario != null)
                    {
                        await CriarCookie(usuario, model.LembrarMe);

                        if (Url.IsLocalUrl(returnUrl) && returnUrl.Length > 1 && returnUrl.StartsWith("/")
                       && !returnUrl.StartsWith("//") && !returnUrl.StartsWith("/\\"))
                        {
                            return Redirect(returnUrl);
                        }
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "O nome de usuário ou senha estão incorretos.");
                    }
                }
                catch
                {
                    ModelState.AddModelError(string.Empty, Mensagens.MS_002);
                }
            }
            return View(model);
        }

        #endregion

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            try
            {
                await HttpContext.SignOutAsync(scheme: CookieAuthenticationDefaults.AuthenticationScheme);
            }
            catch { }
            return RedirectToAction("Login", "Conta");
        }

        private async Task CriarCookie(UsuarioDTO usuario, bool lembrarMe)
        {
            try
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.NameIdentifier, usuario.Id.ToString(),ClaimValueTypes.Integer),
                    new Claim(ClaimTypes.Name, usuario.Nome,ClaimValueTypes.String),
                    new Claim(ClaimTypes.Email, usuario.Email, ClaimValueTypes.String)
                };

                foreach (var loop in usuario.VinculoUsuarioRole)
                {
                    if (loop.IdRoleNavigation != null)
                    {
                        claims.Add(new Claim(ClaimTypes.Role, loop.IdRoleNavigation.NomeRole, ClaimValueTypes.String));
                    }
                }

                var claimsIdentity = new ClaimsIdentity(
                    claims, CookieAuthenticationDefaults.AuthenticationScheme);

                var authProperties = new AuthenticationProperties
                {
                    AllowRefresh = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddDays(Constantes.TEMPO_DIA_EXPIRAR_LOGIN),
                    IsPersistent = lembrarMe
                };

                await HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                        new ClaimsPrincipal(claimsIdentity),
                        authProperties);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}