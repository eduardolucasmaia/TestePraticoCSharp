﻿using Business.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
#if !DEBUG
using Microsoft.AspNetCore.Authorization;
#endif

namespace TesteInvillia.Controllers.api
{
#if !DEBUG
    [Authorize(Roles = Constantes.ROLE_USUARIO)]
#endif
    [Produces("application/json")]
    [Route("api/Usuario/[action]")]
    [ApiController]
    public class UsuarioController : HttpContextAcessorController
    {
        #region Construtor

        private readonly IUsuarioBusiness _usuarioBusiness;

        public UsuarioController(IUsuarioBusiness usuarioBusiness, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _usuarioBusiness = usuarioBusiness;
        }

        #endregion

        #region AÇÕES

        [HttpPost]
        [ActionName("SalvarUsuario")]
        public async Task<RetornoGenerico<UsuarioDTO>> SalvarUsuario([FromForm] UsuarioDTO model)
        {
            try
            {
                if (model.Id == 0)
                {
                    var usuario = await _usuarioBusiness.BuscarUsuarioPorEmail(model.Email);
                    if (usuario != null)
                    {
                        return new RetornoGenerico<UsuarioDTO>()
                        {
                            Retorno = model,
                            IsSucesso = false,
                            Mensagem = Mensagens.MS_014,
                            TipoMensagem = Constantes.TIPO_MENSAGEM_ALERTA
                        };
                    }
                }

                model.IdCriadoUsuario = RecuperarIdUsuario();
                await _usuarioBusiness.SalvarUsuario(model);
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = model,
                    IsSucesso = true,
                    Mensagem = model.Id != 0 ? Mensagens.MS_011 : Mensagens.MS_010,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_SUCESSO
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = model,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        [HttpDelete]
        [ActionName("ExcluirUsuario")]
        public async Task<RetornoGenerico<int>> ExcluirUsuario([FromForm] int id)
        {
            try
            {
                await _usuarioBusiness.ExcluirUsuario(id);
                return new RetornoGenerico<int>()
                {
                    Retorno = id,
                    IsSucesso = true,
                    Mensagem = Mensagens.MS_012,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_SUCESSO
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<int>()
                {
                    Retorno = id,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        #endregion

        #region CONSULTAS

        [HttpGet]
        [ActionName("BuscarUsuarios")]
        public async Task<RetornoGenerico<List<UsuarioDTO>>> BuscarUsuarios()
        {
            try
            {
                var returno = await _usuarioBusiness.BuscarUsuarios(RecuperarIdUsuario());
                return new RetornoGenerico<List<UsuarioDTO>>()
                {
                    Retorno = returno,
                    IsSucesso = true
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<List<UsuarioDTO>>()
                {
                    Retorno = null,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        [HttpGet]
        [ActionName("BuscarUsuarioPorId")]
        public async Task<RetornoGenerico<UsuarioDTO>> BuscarUsuarioPorId(int id)
        {
            try
            {
                var returno = await _usuarioBusiness.BuscarUsuarioPorId(id);
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = returno,
                    IsSucesso = true
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = null,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        #endregion

    }
}