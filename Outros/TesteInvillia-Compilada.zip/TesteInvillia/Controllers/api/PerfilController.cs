﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Business.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TesteInvillia.Models;
#if !DEBUG
using Microsoft.AspNetCore.Authorization;
#endif

namespace TesteInvillia.Controllers.api
{
#if !DEBUG
    [Authorize]
#endif
    [Produces("application/json")]
    [Route("api/Perfil/[action]")]
    [ApiController]
    public class PerfilController : HttpContextAcessorController
    {
        #region Construtor

        private readonly IUsuarioBusiness _usuarioBusiness;

        public PerfilController(IUsuarioBusiness usuarioBusiness, IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _usuarioBusiness = usuarioBusiness;
        }

        #endregion

        #region AÇÕES

        [HttpPost]
        [ActionName("AtualizarPerfil")]
        public async Task<RetornoGenerico<UsuarioDTO>> AtualizarPerfil([FromForm] UsuarioDTO model)
        {
            try
            {
                await _usuarioBusiness.AtualizarPerfil(model, RecuperarIdUsuario());
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = model,
                    IsSucesso = true,
                    Mensagem = Mensagens.MS_011,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_SUCESSO
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = model,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        [HttpPost]
        [ActionName("TrocarSenha")]
        public async Task<object> TrocarSenha([FromForm] TrocarSenhaViewModel model)
        {
            try
            {
                var usuario = await _usuarioBusiness.TrocarSenha(model.SenhaAntiga, model.NovaSenha, RecuperarIdUsuario());
                if (usuario == null)
                {
                    HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    ModelState.AddModelError("SenhaAntiga", Mensagens.MS_007);
                    return new Dictionary<string, object>() { ["SenhaAntiga"] = new Dictionary<string, string>() { ["0"] = Mensagens.MS_007 } };
                }
                else
                {
                    return new RetornoGenerico<TrocarSenhaViewModel>()
                    {
                        Retorno = model,
                        IsSucesso = true,
                        Mensagem = Mensagens.MS_011,
                        TipoMensagem = Constantes.TIPO_MENSAGEM_SUCESSO
                    };
                }
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<TrocarSenhaViewModel>()
                {
                    Retorno = model,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        #endregion

        #region CONSULTAS

        [HttpGet]
        [ActionName("BuscarFotoPerfilUsuarioAtual")]
        public async Task<RetornoGenerico<string>> BuscarFotoPerfilUsuarioAtual()
        {
            try
            {
                var returno = await _usuarioBusiness.BuscarFotoPerfilUsuarioAtual(RecuperarIdUsuario());
                return new RetornoGenerico<string>()
                {
                    Retorno = returno,
                    IsSucesso = true
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<string>()
                {
                    Retorno = "@DTO.Ferramentas.Constantes.IMAGEM_SEM_IMAGEM",
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        [HttpGet]
        [ActionName("BuscarUsuarioAtual")]
        public async Task<RetornoGenerico<UsuarioDTO>> BuscarUsuarioAtual()
        {
            try
            {
                var returno = await _usuarioBusiness.BuscarUsuarioAtual(RecuperarIdUsuario());
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = returno,
                    IsSucesso = true
                };
            }
            catch (Exception ex)
            {
                return new RetornoGenerico<UsuarioDTO>()
                {
                    Retorno = null,
                    IsSucesso = false,
                    Mensagem = Mensagens.MS_002,
                    TipoMensagem = Constantes.TIPO_MENSAGEM_ERRO,
                    Exception = ex
                };
            }
        }

        #endregion

    }
}