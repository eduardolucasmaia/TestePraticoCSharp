﻿using AutoMapper;
using Business.Entities.DataModels;
using Business.Interfaces;
using Data.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class UsuarioBusiness : BaseBusiness, IUsuarioBusiness
    {
        #region Construtor

        private readonly IUsuarioData _usuarioData;
        private readonly IJogoData _jogoData;
        private readonly IMapper _mapper;
        public UsuarioBusiness(IUsuarioData usuarioData, IJogoData jogoData, IMapper mapper)
        {
            _jogoData = jogoData;
            _usuarioData = usuarioData;
            _mapper = mapper;
        }

        #endregion

        #region CONSULTA

        public async Task<UsuarioDTO> AutenticarUsuario(string username, string senha)
        {
            try
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<Role, RoleDTO>()
                    .ForMember(x => x.VinculoUsuarioRole, opt => opt.Ignore());
                    cfg.CreateMap<Usuario, UsuarioDTO>()
                    .ForMember(x => x.InverseIdCriadoUsuarioNavigation, opt => opt.Ignore());
                    cfg.CreateMap<VinculoUsuarioRole, VinculoUsuarioRoleDTO>()
                    .ForMember(x => x.IdUsuarioNavigation, opt => opt.Ignore());
                });
                IMapper mapper = config.CreateMapper();
                return mapper.Map<UsuarioDTO>(await _usuarioData.AutenticarUsuario(username, senha));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<UsuarioDTO>> BuscarUsuarios(int id)
        {
            try
            {
                var mapper = RemoverReferenciaCircularJogo();
                return mapper.Map<List<UsuarioDTO>>(await _usuarioData.BuscarUsuarios(id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UsuarioDTO> BuscarUsuarioPorId(int id)
        {
            try
            {
                var mapper = RemoverReferenciaCircularJogo();
                return mapper.Map<UsuarioDTO>(await _usuarioData.BuscarUsuarioPorId(id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UsuarioDTO> BuscarUsuarioPorEmail(string email)
        {
            try
            {
                return _mapper.Map<UsuarioDTO>(await _usuarioData.BuscarUsuarioPorEmail(email));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<string> BuscarFotoPerfilUsuarioAtual(int id)
        {
            try
            {
                return await _usuarioData.BuscarFotoPerfilUsuarioAtual(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UsuarioDTO> BuscarUsuarioAtual(int id)
        {
            try
            {
                return _mapper.Map<UsuarioDTO>(await _usuarioData.BuscarUsuarioPorId(id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IMapper RemoverReferenciaCircularJogo()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Jogo, JogoDTO>()
                .ForMember(x => x.FotoBase64, opt => opt.Ignore())
                .ForMember(x => x.MiniaturaBase64, opt => opt.Ignore())
                .ForMember(x => x.IdUsuarioNavigation, opt => opt.Ignore());
                cfg.CreateMap<Usuario, UsuarioDTO>()
                .ForMember(x => x.Senha, opt => opt.Ignore())
                .ForMember(x => x.InverseIdCriadoUsuarioNavigation, opt => opt.Ignore());
                cfg.CreateMap<Role, RoleDTO>()
                .ForMember(x => x.VinculoUsuarioRole, opt => opt.Ignore());
                cfg.CreateMap<VinculoUsuarioRole, VinculoUsuarioRoleDTO>()
                .ForMember(x => x.IdUsuarioNavigation, opt => opt.Ignore());
            });
            return config.CreateMapper();
        }

        #endregion

        #region AÇÕES

        public async Task<bool> SalvarUsuario(UsuarioDTO model)
        {
            try
            {
                var usuario = await _usuarioData.BuscarUsuarioPorId(model.Id);

                List<Jogo> listaJogos = null;

                if (model.JogosSelecionados != null && model.JogosSelecionados.Count > 0)
                {
                    listaJogos = await _jogoData.BuscarJogosIn(model.JogosSelecionados, model.Id);
                }

                if (usuario != null)
                {
                    usuario.DataAlteracao = DateTime.Now;
                    usuario.Excluido = false;
                    usuario.Telefone = model.Telefone?.Trim();
                    usuario.Nome = model.Nome.Trim();
                    usuario.Cpf = model.Cpf?.Trim();
                    usuario.Email = model.Email.Trim();
                    usuario.Observacao = model.Observacao?.Trim();
                    usuario.FotoBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_ORIGINAL, model.FotoBase64);
                    usuario.MiniaturaBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_THUMBNAIL, model.FotoBase64);

                    //Usuário Possui jogo
                    if (usuario.Jogo != null && usuario.Jogo.Count > 0)
                    {
                        //Limpa a lista de jogos dele
                        usuario.Jogo.ToList().ForEach(c => { c.IdUsuario = null; c.IdUsuarioNavigation = null; });

                        //Lista veio preechida
                        if (listaJogos != null && listaJogos.Count > 0)
                        {
                            //Passa todas para o id do usuário
                            listaJogos.ForEach(c => c.IdUsuario = usuario.Id);

                            //Percorre a iista
                            foreach (var loop in listaJogos)
                            {
                                //verifica se não está na lista
                                if (!usuario.Jogo.ToList().Exists(x => x.Id == loop.Id))
                                {
                                    //Se não estiver adiciona a coleção
                                    usuario.Jogo.Add(loop);
                                }
                                else
                                {
                                    //Se estiver na lista devolve para o id dele.
                                    usuario.Jogo.Where(x => x.Id == loop.Id).Select(x => { x.IdUsuario = model.Id; return x; }).ToList();
                                }
                            }
                        }
                    }
                    else
                    {
                        if (listaJogos != null && listaJogos.Count > 0)
                        {
                            listaJogos.ForEach(c => c.IdUsuario = usuario.Id);
                            usuario.Jogo = listaJogos;
                        }
                    }
                }
                else
                {
                    usuario = new Usuario()
                    {
                        Id = 0,
                        DataCadastro = DateTime.Now,
                        DataAlteracao = new Nullable<DateTime>(),
                        Excluido = false,
                        IdCriadoUsuario = model.IdCriadoUsuario,
                        Telefone = model.Telefone?.Trim(),
                        Nome = model.Nome.Trim(),
                        Cpf = model.Cpf?.Trim(),
                        Email = model.Email.Trim(),
                        Observacao = model.Observacao?.Trim(),
                        Senha = Constantes.SENHA_INICIAL,
                        FotoBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_ORIGINAL, model.FotoBase64),
                        MiniaturaBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_THUMBNAIL, model.FotoBase64),
                        Jogo = listaJogos
                    };
                }

                return await _usuarioData.SalvarUsuario(usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> AtualizarPerfil(UsuarioDTO model, int id)
        {
            try
            {
                var usuario = await _usuarioData.BuscarUsuarioPorId(id);
                if (usuario != null)
                {
                    usuario.Nome = string.IsNullOrEmpty(model.Nome) ? null : model.Nome.Trim();
                    usuario.Email = string.IsNullOrEmpty(model.Email) ? null : model.Email.Trim();
                    usuario.Cpf = string.IsNullOrEmpty(model.Cpf) ? null : model.Cpf.Trim();
                    usuario.Telefone = string.IsNullOrEmpty(model.Telefone) ? null : model.Telefone.Trim();
                    usuario.Observacao = string.IsNullOrEmpty(model.Observacao) ? null : model.Observacao.Trim();
                    usuario.FotoBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_ORIGINAL, model.FotoBase64);
                    usuario.MiniaturaBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_THUMBNAIL, model.FotoBase64);
                    usuario.DataAlteracao = DateTime.Now;
                    usuario.Excluido = false;

                    return await _usuarioData.SalvarUsuario(usuario);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ExcluirUsuario(int id)
        {
            try
            {
                return await _usuarioData.ExcluirUsuario(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<UsuarioDTO> TrocarSenha(string senhaAntiga, string novaSenha, int id)
        {
            try
            {
                return _mapper.Map<UsuarioDTO>(await _usuarioData.TrocarSenha(senhaAntiga, novaSenha, id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}
