﻿using System;
using System.Drawing;
using System.IO;

namespace Business
{
    public class BaseBusiness
    {
        protected bool ResizeAbort()
        {
            return false;
        }

        public string ResizeImage(int width, string fotoBase64)
        {
            try
            {
                if (!string.IsNullOrEmpty(fotoBase64))
                {
                    var base64String = fotoBase64.Remove(0, fotoBase64.IndexOf(',') + 1);
                    byte[] bytes = Convert.FromBase64String(base64String);

                    using (MemoryStream ms = new MemoryStream(bytes))
                    {
                        var image = Image.FromStream(ms);
                        int X = image.Width;
                        int Y = image.Height;
                        int height = (int)((width * Y) / X);
                        var dummyCallback = new Image.GetThumbnailImageAbort(ResizeAbort);
                        var thumbnailImage = image.GetThumbnailImage(width, height, dummyCallback, IntPtr.Zero);
                        //thumbnailImage.Save(@"D:\Desktop\Desktop\" + width.ToString() + "-test.jpg");
                        using (MemoryStream imageStream = new MemoryStream())
                        {
                            thumbnailImage.Save(imageStream, System.Drawing.Imaging.ImageFormat.Bmp);
                            imageStream.Position = 0;
                            byte[] imageBytes = imageStream.ToArray();
                            base64String = Convert.ToBase64String(imageBytes);
                            base64String = fotoBase64.Substring(0, fotoBase64.IndexOf(',') + 1) + base64String;
                            return base64String;
                        }
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }
    }
}