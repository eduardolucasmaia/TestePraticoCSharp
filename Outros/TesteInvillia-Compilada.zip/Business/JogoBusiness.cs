﻿using AutoMapper;
using Business.Entities.DataModels;
using Business.Interfaces;
using Data.Interfaces;
using DTO.DTO;
using DTO.Ferramentas;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business
{
    public class JogoBusiness : BaseBusiness, IJogoBusiness
    {
        #region Construtor

        private readonly IJogoData _jogoData;
        private readonly IMapper _mapper;

        public JogoBusiness(IJogoData jogoData, IMapper mapper)
        {
            _jogoData = jogoData;
            _mapper = mapper;
        }

        #endregion

        #region CONSULTAS

        public async Task<List<JogoDTO>> BuscarJogosDisponiveis(int id)
        {
            try
            {
                var mapper = RemoverReferenciaCircularUsuario();
                return mapper.Map<List<JogoDTO>>(await _jogoData.BuscarJogosDisponiveis(id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<JogoDTO>> BuscarJogos()
        {
            try
            {
                var mapper = RemoverReferenciaCircularUsuario();
                return mapper.Map<List<JogoDTO>>(await _jogoData.BuscarJogos());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<JogoDTO>> BuscarJogoPorNome(string nome)
        {
            try
            {
                nome = nome ?? string.Empty;
                var mapper = RemoverReferenciaCircularUsuario();
                return mapper.Map<List<JogoDTO>>(await _jogoData.BuscarJogoPorNome(nome.Trim()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<JogoDTO> BuscarJogoPorId(int id)
        {
            try
            {
                return _mapper.Map<JogoDTO>(await _jogoData.BuscarJogoPorId(id));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IMapper RemoverReferenciaCircularUsuario()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Jogo, JogoDTO>()
                .ForMember(x => x.FotoBase64, opt => opt.Ignore());

                cfg.CreateMap<Usuario, UsuarioDTO>()
                .ForMember(x => x.Jogo, opt => opt.Ignore())
                .ForMember(x => x.FotoBase64, opt => opt.Ignore())
                .ForMember(x => x.MiniaturaBase64, opt => opt.Ignore())
                .ForMember(x => x.Senha, opt => opt.Ignore())
                .ForMember(x => x.InverseIdCriadoUsuarioNavigation, opt => opt.Ignore());
            });
            return config.CreateMapper();
        }

        #endregion

        #region AÇÕES

        public async Task<bool> SalvarJogo(JogoDTO model)
        {
            try
            {
                var jogo = await _jogoData.BuscarJogoPorId(model.Id);

                if (jogo != null)
                {
                    jogo.DataAlteracao = DateTime.Now;
                    jogo.FotoBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_ORIGINAL, model.FotoBase64);
                    jogo.MiniaturaBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_THUMBNAIL, model.FotoBase64);
                    jogo.Excluido = false;
                    jogo.Descricao = model.Descricao?.Trim();
                    jogo.Nome = model.Nome.Trim();
                    jogo.Observacao = model.Observacao?.Trim();
                    jogo.IdUsuario = model.IdUsuario == null ? null : (model.IdUsuario.Value == 0 ? null : model.IdUsuario);
                    jogo.Plataforma = model.Plataforma > Constantes.PLATAFORMAS.Count ? Constantes.SEM_PLATAFORMA_ID : model.Plataforma;
                }
                else
                {
                    jogo = new Jogo()
                    {
                        Id = 0,
                        DataCadastro = DateTime.Now,
                        DataAlteracao = new Nullable<DateTime>(),
                        FotoBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_ORIGINAL, model.FotoBase64),
                        MiniaturaBase64 = string.IsNullOrEmpty(model.FotoBase64) ? null : ResizeImage(Constantes.TAMANHO_IMAGEM_THUMBNAIL, model.FotoBase64),
                        Excluido = false,
                        Descricao = model.Descricao?.Trim(),
                        Nome = model.Nome.Trim(),
                        Observacao = model.Observacao?.Trim(),
                        IdUsuario = model.IdUsuario == null ? null : (model.IdUsuario.Value == 0 ? null : model.IdUsuario),
                        Plataforma = model.Plataforma > Constantes.PLATAFORMAS.Count ? Constantes.SEM_PLATAFORMA_ID : model.Plataforma
                    };
                }
                return await _jogoData.SalvarJogo(jogo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ExcluirJogo(int id)
        {
            try
            {
                return await _jogoData.ExcluirJogo(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}