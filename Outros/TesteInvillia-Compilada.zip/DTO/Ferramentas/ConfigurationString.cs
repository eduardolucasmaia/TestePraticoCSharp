﻿using System.Collections.Generic;

namespace DTO.Ferramentas
{
    public static class ConfigurationString
    {
        public static Dictionary<string, string> Connection = new Dictionary<string, string>();
    }
}