﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Ferramentas
{
    public class Plataforma
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
