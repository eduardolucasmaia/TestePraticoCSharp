﻿using DTO.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Interfaces
{
    public interface IUsuarioBusiness
    {
        #region CONSULTAS
        Task<UsuarioDTO> AutenticarUsuario(string username, string senha);
        Task<List<UsuarioDTO>> BuscarUsuarios(int id);
        Task<UsuarioDTO> BuscarUsuarioPorId(int id);
        Task<UsuarioDTO> BuscarUsuarioPorEmail(string email);
        Task<string> BuscarFotoPerfilUsuarioAtual(int id);
        Task<UsuarioDTO> BuscarUsuarioAtual(int id);
        #endregion
        #region AÇÕES
        Task<bool> SalvarUsuario(UsuarioDTO model);
        Task<bool> AtualizarPerfil(UsuarioDTO model, int id);
        Task<bool> ExcluirUsuario(int id);
        Task<UsuarioDTO> TrocarSenha(string senhaAntiga, string novaSenha, int id);
        #endregion
    }
}