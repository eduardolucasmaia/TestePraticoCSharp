﻿using DTO.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Interfaces
{
    public interface IJogoBusiness
    {
        #region AÇÕES
        Task<bool> SalvarJogo(JogoDTO model);
        Task<bool> ExcluirJogo(int id);
        #endregion

        #region CONSULTAS
        Task<List<JogoDTO>> BuscarJogosDisponiveis(int id);
        Task<List<JogoDTO>> BuscarJogos();
        Task<List<JogoDTO>> BuscarJogoPorNome(string nome);
        Task<JogoDTO> BuscarJogoPorId(int id);
        #endregion
    }
}
