﻿namespace TesteInvillia.IntegrationTests.Config
{
    public static class ConnectionStringTests
    {
        /// <summary>
        /// Connection String utilizada nos Testes
        /// </summary>
        public static string CONNECTION_STRING_TEST = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=TesteInvillia;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }
}
